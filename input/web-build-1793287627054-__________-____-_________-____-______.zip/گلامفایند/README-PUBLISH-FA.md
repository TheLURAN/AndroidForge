# نسخه اندروید گلام‌فایند

این پروژه اکنون یک پروژه واقعی Android Gradle است و فایل‌های لازم برای اجرای دستور `gradle assembleRelease` را دارد؛ خطای قبلی به این دلیل بود که پوشه فقط شامل پروژه React/Vite بود و فایل‌های `settings.gradle` و `build.gradle` اندروید نداشت.

## ساخت APK
در ریشه همین پوشه اجرا کنید:
```bash
gradle assembleDebug
```
یا برای نسخه انتشار:
```bash
gradle assembleRelease
```

خروجی معمول:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk`

APK انتشار unsigned است و برای انتشار در Google Play باید با کلید امضای خودتان امضا شود. برای انتشار در Google Play معمولاً خروجی AAB امضاشده لازم است.

## نکته مهم
اپلیکیشن سایت `https://glamfind.ir/?application=true&app_version=1.0.0` را در WebView نمایش می‌دهد؛ بنابراین برای نمایش محتوای سایت به اینترنت نیاز دارد. پیش از انتشار، عملکرد ورود، پرداخت، آپلود فایل، اعلان‌ها و لینک‌های خارجی را روی دستگاه واقعی آزمایش کنید.
