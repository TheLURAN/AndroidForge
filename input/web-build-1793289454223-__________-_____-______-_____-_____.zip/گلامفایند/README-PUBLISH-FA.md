# نسخه اندروید گلام‌فایند

این پروژه اکنون یک پروژه واقعی Android Gradle است و فایل‌های لازم برای اجرای دستور `gradle assembleRelease` را دارد؛ خطای قبلی به این دلیل بود که پوشه فقط شامل پروژه React/Vite بود و فایل‌های `settings.gradle` و `build.gradle` اندروید نداشت.

## ساخت APK
در ریشه همین پوشه اجرا کنید:
```bash
gradle assembleDebug
```
یا برای نسخه انتشار:
```bash
gradle assembleRelease
```

خروجی معمول:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk`

APK انتشار unsigned است و برای انتشار در Google Play باید با کلید امضای خودتان امضا شود. برای انتشار در Google Play معمولاً خروجی AAB امضاشده لازم است.

## نکته مهم
اپلیکیشن سایت `https://glamfind.ir/?application=true&app_version=1.0.0` را در WebView نمایش می‌دهد؛ بنابراین برای نمایش محتوای سایت به اینترنت نیاز دارد. پیش از انتشار، عملکرد ورود، پرداخت، آپلود فایل، اعلان‌ها و لینک‌های خارجی را روی دستگاه واقعی آزمایش کنید.

## حالت بارگذاری و نشان برنامه
- صفحهٔ بارگذاری اندروید از نشان شفاف گلام‌فایند استفاده می‌کند و تا پایان بارگذاری صفحه نمایش داده می‌شود.
- نشان برنامه در منابع Android Launcher قرار داده شده است.
- برای وب نیز فایل `public/glamfind-logo.png` به‌عنوان نشان صفحه و تصویر بارگذاری استفاده می‌شود.

## ساخت AAB امضاشده برای Google Play
برای امنیت، فایل کلید امضا را داخل پروژه یا ZIP قرار ندهید. یک keystore بسازید:
```bash
keytool -genkeypair -v -keystore glamfind-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias glamfind
```
سپس متغیرهای محیطی زیر را با مقادیر واقعی تنظیم کنید:
- `ANDROID_KEYSTORE_PATH` مسیر فایل `glamfind-release.jks`
- `ANDROID_KEYSTORE_PASSWORD` رمز keystore
- `ANDROID_KEY_ALIAS` مقدار `glamfind` (یا alias انتخابی خودتان)
- `ANDROID_KEY_PASSWORD` رمز کلید

پس از نصب JDK و Gradle و تنظیم Android SDK اجرا کنید:
```bash
gradle bundleRelease
```
خروجی در `app/build/outputs/bundle/release/app-release.aab` قرار می‌گیرد. اگر متغیرهای امضا تنظیم نشده باشند، خروجی انتشار امضاشده نخواهد بود. کلید و رمزها را محرمانه نگه دارید و از keystore نسخهٔ پشتیبان امن تهیه کنید.

## انتشار در کافه‌بازار و مایکت

پروژه flavorهای جداگانه برای ساخت خروجی انتشار این دو فروشگاه دارد. راهنمای کامل ساخت APK/AAB امضاشده، تنظیم کلید و ارسال به پنل‌ها در فایل `PUBLISH-BAZAAR-MYKET-FA.md` قرار دارد.

دستورهای ساخت:
```bash
gradle assembleBazaarRelease
gradle assembleMyketRelease
```

برای ساخت AAB کافه‌بازار:
```bash
gradle bundleBazaarRelease
```

ساخت خروجی به معنی انتشار خودکار نیست؛ بارگذاری و بررسی نهایی از پنل رسمی فروشگاه و با حساب توسعه‌دهنده انجام می‌شود.
