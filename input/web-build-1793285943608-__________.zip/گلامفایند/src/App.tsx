import { useEffect, useState } from 'react';
import { WifiOff, RefreshCw, AlertCircle } from 'lucide-react';

const SITE_URL = 'https://glamfind.ir/?application=true&app_version=1.0.0';
const LOGO_URL = 'https://glamfind.ir/wp-content/themes/glamfind/assets/img/favicon.png';

type PageState = 'loading' | 'ready' | 'error';

function App() {
  const [frameKey, setFrameKey] = useState(0);
  const [pageState, setPageState] = useState<PageState>('loading');
  const [online, setOnline] = useState(() => navigator.onLine);
  const [logoFailed, setLogoFailed] = useState(false);

  useEffect(() => {
    document.title = 'گلام‌فایند';
    const updateConnection = () => {
      setOnline(navigator.onLine);
      if (!navigator.onLine) setPageState('error');
    };
    window.addEventListener('online', updateConnection);
    window.addEventListener('offline', updateConnection);
    return () => {
      window.removeEventListener('online', updateConnection);
      window.removeEventListener('offline', updateConnection);
    };
  }, []);

  useEffect(() => {
    if (pageState !== 'loading' || !online) return;
    const timeout = window.setTimeout(() => setPageState('error'), 15000);
    return () => window.clearTimeout(timeout);
  }, [frameKey, pageState, online]);

  const retry = () => {
    setPageState('loading');
    setFrameKey((current) => current + 1);
  };

  const showError = !online || pageState === 'error';

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-white" dir="rtl" data-testid="site-container">
      <iframe
        key={frameKey}
        src={SITE_URL}
        title="وب‌سایت گلام‌فایند"
        data-testid="live-site-frame"
        className="absolute inset-0 h-full w-full border-0 bg-white"
        allow="geolocation; camera; microphone; clipboard-read; clipboard-write"
        onLoad={() => setPageState((current) => current === 'loading' ? 'ready' : current)}
        onError={() => setPageState('error')}
      />

      <div
        className={`absolute inset-0 z-10 flex flex-col items-center justify-center bg-[#DA3333] px-6 text-white transition-opacity duration-500 ease-out ${pageState === 'ready' && online ? 'pointer-events-none opacity-0' : 'opacity-100'}`}
        style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
        aria-hidden={showError || pageState === 'ready'}
        data-testid="splash-screen"
      >
        <div className="flex flex-col items-center gap-8">
          <div className="flex size-24 items-center justify-center overflow-hidden rounded-[22px] bg-white p-3 shadow-[0_14px_45px_rgba(84,10,10,.2)] sm:size-28">
            {logoFailed ? (
              <span className="text-5xl font-black text-[#DA3333]" aria-label="گلام‌فایند">گ</span>
            ) : (
              <img src={LOGO_URL} alt="نشان گلام‌فایند" className="h-full w-full object-contain" onError={() => setLogoFailed(true)} />
            )}
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-extrabold">گلام‌فایند</h1>
            <p className="mt-2 text-sm text-white/85">زیبایی، نزدیک‌تر از همیشه</p>
          </div>
          <span className="size-7 animate-spin rounded-full border-[3px] border-white/30 border-t-white" role="status" aria-label="در حال بارگذاری" />
        </div>
      </div>

      {showError && (
        <div
          className="absolute inset-0 z-20 flex items-center justify-center bg-[#f2f2f7] px-5 text-[#333333]"
          style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
          data-testid="error-state"
        >
          <div className="w-full max-w-sm rounded-[15px] bg-white px-6 py-8 text-center shadow-[0_10px_40px_rgba(30,30,50,.08)]">
            <div className="mx-auto mb-5 flex size-16 items-center justify-center rounded-full bg-[#DA3333]/10 text-[#DA3333]">
              {online ? <AlertCircle size={32} aria-hidden="true" /> : <WifiOff size={32} aria-hidden="true" />}
            </div>
            <h2 className="text-xl font-extrabold">{online ? 'سایت بارگذاری نشد' : 'اتصال اینترنت قطع شده'}</h2>
            <p className="mt-3 text-sm leading-7 text-[#666666]">
              {online
                ? 'لطفاً اتصال اینترنت را بررسی کنید و دوباره تلاش کنید. اگر مشکل ادامه داشت، ممکن است سایت اجازهٔ نمایش در این قاب را ندهد.'
                : 'برای استفاده از گلام‌فایند به اینترنت وصل شوید و دوباره تلاش کنید.'}
            </p>
            <button
              type="button"
              onClick={retry}
              data-testid="retry-site"
              className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-[10px] bg-[#DA3333] px-5 font-bold text-white transition-colors hover:bg-[#bb2929] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#DA3333]"
            >
              <RefreshCw size={18} aria-hidden="true" />
              تلاش مجدد
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

export default App;
