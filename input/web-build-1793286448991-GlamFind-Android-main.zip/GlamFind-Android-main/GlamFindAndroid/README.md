# GlamFind Android — Version 1.0.0

Android WebView wrapper for `https://glamfind.ir/?application=true&app_version=1.0.0`.

- Application ID: `ir.glamfind`
- Display name: گلام‌فایند
- Version: `1.0.0` (versionCode 1)
- Primary color: `#DA3333`
- Minimum Android: 6.0 (API 23)
- Target/compile SDK: 35

## Included
- WebView with JavaScript and DOM storage
- Persistent cookies/session support
- Splash screen and top progress indicator
- Internal navigation for `glamfind.ir` and its subdomains
- External handling for other domains and telephone/mail/app links
- HTML file chooser support for upload fields
- DownloadManager integration
- Android back button navigation
- HTTPS-only network policy

## Build APK / AAB
This folder is an Android Studio project. To compile it, install Android Studio with Android SDK Platform 35 and JDK 17, open this folder, let Gradle sync, then choose:

- **Build > Build Bundle(s) / APK(s) > Build APK(s)** for APK
- **Build > Generate Signed Bundle / APK** for a release-signed APK or Play Store AAB

Debug APK output after a successful build:
`app/build/outputs/apk/debug/app-debug.apk`

Release distribution builds must be signed with a keystore controlled by the app owner. Do not publish a debug APK as a production release.

## Before store submission
Test login/session retention, all upload flows, phone/email links, payment flows if any, and downloads on physical devices. Review each marketplace's current policies. This project does not include push notifications or a signing keystore.
